/*
 * init_devices.h
 *
 *  Created on: 5 de may. de 2020
 *      Author: steckler
 */

#ifndef SRC_INIT_DEVICES_H_
#define SRC_INIT_DEVICES_H_

void TIMER0_init(void);
void WTIMER0_init(void); //phototransistor
void TIMER1_init(void);

void SIRC_RX_LOWe_init(void);
void SIRC_TX_init(void);
void SIRC_RX_init(void);
void setupLetimeroff(void);

typedef struct
{
   uint8_t FieldBit;   /*!< Field bit */
   uint8_t ToggleBit;  /*!< Toggle bit field */
   uint8_t Address;    /*!< Address field */
   uint8_t Command;    /*!< Command field */

} RC5_Frame_TypeDef;
typedef struct
{
 uint16_t data;     /*!< RC5 data */
 uint8_t  status;   /*!< RC5 status */
 uint8_t  lastBit;  /*!< RC5 last bit */
 uint8_t  bitCount; /*!< RC5 bit count */
} tRC5_packet;
enum RC5_lastBitType
{
  RC5_ZER,
  RC5_ONE,
  RC5_NAN,
  RC5_INV
};
typedef enum RC5_lastBitType tRC5_lastBitType;


// decode variables
typedef struct {
	uint32_t command : 6;
	uint32_t addr    : 5;
	uint32_t toggle  : 1;
	uint32_t start_2 : 1;
	uint32_t start_1 : 1;
}RC_5_packet_t;

volatile union {
  RC_5_packet_t packet;
  uint32_t data;
}RC_5_transmission;



#endif /* SRC_INIT_DEVICES_H_ */
