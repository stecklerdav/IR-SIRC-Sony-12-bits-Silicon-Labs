
                                                //SIRC Tx Rx


//Name: David J. Steckler V.
// +58-412-7424079
//.ve
// stecklerdav@hotmal.com/gmail.com
// I'm a freelance ;)
// June 19 2020


// I do all kind of microcontroller code, contact me...


//Board: SLSTK3402A MCU:EFM32PG12B500F1024GL125

// it was tested for: SONY TV RM-YD063 model remote control
//                  : DIRECTV RC65SL   model remote control

//SIRC protocol Tx, Rx and Rx Low Energy

//configuration modes comment or not these:  #define LOW
//                                           #define TX

//it is recommend non low energy mode for High precision


//to debug see SIRC_FRAME struct to see the detection code


//WARNING: in LOW mode Tx doens`t work because microcontroller is in EM2 deep sleep and TIMERS,

//modes available: TX and RX on in EM1
//                 only RX in EM1
//                 only RX in EM2

#include "em_device.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "em_prs.h"
#include "em_system.h"
#include "em_timer.h"
#include "em_letimer.h"

#include "em_chip.h"
#include "string.h"
#include "math.h"
#include "init_devices.h"
#include "ir.h"

#define OUTPUT_PORT gpioPortD
#define OUTPUT_PIN 10
#define HFPERCLK_IN_MHZ 19
#define WTIMER0_PRESCALE timerPrescale1

volatile bool SIRC_TX_complete = false;
volatile uint32_t  r = 0;
volatile uint32_t ii = 0;
// Most recent measured period in microseconds
volatile uint32_t measured_period;
// Stored edge from previous interrupt
volatile uint32_t last_captured_edge;
// Number of timer overflows since last interrupt;
volatile uint32_t overflow_count;
volatile uint16_t periodsArray[80];
uint32_t TIMCLKValueKHz;
SIRC_Frame_TypeDef SIRC_FRAME;
volatile tSIRC_packet IRTmpPacket; /*!< IR packet*/
extern  bool IRFrameReceived;
extern uint32_t SIRC12_FramePulseWidthFormat[SIRC12_CODED_FRAME_TABLE_LENGTH];



void SIRC_SONY_Decode(SIRC_Frame_TypeDef *ir_frame);

int main(void) {
  /* Initialize chip */


 CHIP_Init();
// Init DCDC regulator with kit specific parameters
  EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
  EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
  EMU_EM01Init_TypeDef em01Init = EMU_EM01INIT_DEFAULT;
  em01Init.vScaleEM01LowPowerVoltageEnable = true;// Because flash memory must have high voltage on EM1
  em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;

  // Initialize DCDC.
  EMU_DCDCInit(&dcdcInit);
  // Initialize EM0123 with default parameters
  EMU_EM01Init(&em01Init);
  EMU_EM23Init(&em23Init);

  SystemCoreClockUpdate();
  CMU_HFRCOBandSet(cmuHFRCOFreq_19M0Hz);
  CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);
  CMU_ClockEnable(cmuClock_HFLE, true);
  // Select LFXO for the LETIMER
  CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_LFXO);
  CMU_ClockEnable(cmuClock_LETIMER0, true);
//#endif
  /* Enable clock for GPIO module */
  CMU_ClockEnable(cmuClock_GPIO, true);

  GPIO_PinModeSet(OUTPUT_PORT, OUTPUT_PIN, gpioModePushPull, 0);//salida IR

  // Configure WTIMER0 CC2 Location 31 (PD11) as input
  GPIO_PinModeSet(gpioPortD, 11, gpioModeInput, 1);//PD11 entrada fototransistor

  calibration(TIMCLKValueKHz);

  //config modes--
    //#define LOW
    #define TX
  //--------------

 // 3 modes available
 //    #define LOW
 //  //#define TX
 //        or
 //  //#define LOW
 //  //#define TX
 //        or
 //  //#define LOW
 //    #define TX


  #ifdef LOW
   GPIO_ExtIntConfig(gpioPortD, 11,11,true, true, true);//Despierta el core para luego atender UART
   NVIC_ClearPendingIRQ(GPIO_ODD_IRQn);
   NVIC_EnableIRQ (GPIO_ODD_IRQn);
   SIRC_RX_LOWe_init(); //low energy SIRC reception
  #else
   SIRC_RX_init();
    #ifdef TX
     SIRC_TX_init();// generador de codigo SIRC
    #endif
  #endif

  SIRC_ResetPacket();
 #ifdef TX
  uint32_t delay;
  uint32_t command = 0;
  uint32_t addr = 0;
 #endif

 while (1) { //

  #ifndef LOW
   #ifdef TX
	  SIRC12_Encode_SendFrame(addr,command);
    while(!SIRC_TX_complete);
   #endif
  #endif
  if(IRFrameReceived != false )
  {
   IRFrameReceived = false;
   SIRC_ResetPacket(); //put point test here and see SIRC_FRAME struct in Expressions TAG on DEBUG
  }
  #ifdef TX
   for (delay = 0; delay < 0xAAAA; delay++);
   command++;
   addr++;
   if (addr > 0x1F) { addr = 0; }
   if (command > 0x7F) { command = 0; }
  #endif
  #ifdef LOW
   EMU_EnterEM2(false); // deep sleep
  #else
   EMU_EnterEM1();     // just sleep
  #endif
  }
}
void SIRC_SONY_Decode(SIRC_Frame_TypeDef *ir_frame){
  if(IRFrameReceived != false)
  {
   if(IRTmpPacket.count >= 12)
   {
    SIRC_Decode(&SIRC_FRAME);
   }
 }
}
#ifdef TX
void TIMER1_IRQHandler(void)// only when TX is activated
{	 /* Clear flag for TIMER1 overflow interrupt */
  TIMER_IntClear(TIMER1, TIMER_IF_OF);
  SIRC12_Encode_SignalGenerate(SIRC12_FramePulseWidthFormat);
}
#endif
#ifndef LOW
void WTIMER0_IRQHandler(void)//in RX mode, no LOW mode
{
// Get pending flags and clear
  int irq_flags = TIMER_IntGet(WTIMER0);
  TIMER_IntClear(WTIMER0, WTIMER_IF_CC2 | WTIMER_IF_OF);

  // Read the last captured value from the CC register
  uint32_t current_edge = TIMER_CaptureGet(WTIMER0, 2);
  // Check if timer overflow occurred
  if(irq_flags & WTIMER_IF_OF)
  {
	overflow_count++;
  }
  if(irq_flags & WTIMER_IF_CC2)
  {
	// Calculate period in microseconds, while compensating for overflows
	// Interrupt latency will affect measurements for periods below 3 microseconds (333 kHz)
	measured_period = (overflow_count*(TIMER_TopGet(WTIMER0) + 2) - last_captured_edge + current_edge)
					  / (HFPERCLK_IN_MHZ * (1 << WTIMER0_PRESCALE));
	// Store edge for next period
	last_captured_edge = current_edge;
	// Reset overflow count
	overflow_count = 0;
	if(ii!=0){
	 periodsArray[ii-1] = measured_period;//periodo
	}
	ii++;
	if(ii>25)//
	{
	 periodsArray[ii-1] = 600; //ultimo periodo nominal
	 for(int u = 0; u < 26;u+=2)
	  SIRC_DataSampling((uint32_t)periodsArray[u], (uint32_t)(periodsArray[u]+periodsArray[u+1]));

	 SIRC_SONY_Decode(&SIRC_FRAME);// decode
 	}

 }
}
#endif
#ifdef  LOW
void LETIMER0_IRQHandler(void) //in LOW energy  mode RX
{
	// Get pending flags and clear
	int irq_flag = LETIMER_IntGet(LETIMER0);
	LETIMER_IntClear(LETIMER0, LETIMER_IF_UF);

	if(irq_flag & LETIMER_IF_UF)
	{
	  overflow_count++;
	}
}
 void GPIO_ODD_IRQHandler(void){//only in LOW energy mode RX
    GPIO_IntClear(0xAAAA);
	if(ii==0){
	  LETIMER_Enable(LETIMER0, true);
	  uint32_t current_edge = LETIMER_CounterGet(LETIMER0);
      measured_period = 20*(overflow_count*(LETIMER_TopGet(LETIMER0) + 2) - last_captured_edge + current_edge)/1;
	  last_captured_edge = current_edge;
	  overflow_count = 0;
	}else if(ii!=0){
	  uint32_t current_edge = LETIMER_CounterGet(LETIMER0);
  	  measured_period = 20*(overflow_count*(LETIMER_TopGet(LETIMER0) + 2) - last_captured_edge + current_edge)/1;
	  last_captured_edge = current_edge;
	  overflow_count = 0;
	  periodsArray[ii-1] = measured_period;//periodo
	if(ii > 25)//
	{
	 LETIMER_Enable(LETIMER0, false);
	 periodsArray[ii-1] = 600; //ultimo periodo nominal
	 for(int u = 0; u < 26;u+=2)
	  SIRC_DataSampling((uint32_t)periodsArray[u], (uint32_t)(periodsArray[u]+periodsArray[u+1]));

	 SIRC_SONY_Decode(&SIRC_FRAME);// decode
	}
   }
	ii++;
}
#endif
