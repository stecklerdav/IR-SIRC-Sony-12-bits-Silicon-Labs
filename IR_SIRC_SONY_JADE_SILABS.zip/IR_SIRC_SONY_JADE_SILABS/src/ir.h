/*
 * ir.h
 *
 *  Created on: 5 de may. de 2020
 *      Author: steckler
 */

#ifndef SRC_IR_H_
#define SRC_IR_H_



#define  SIRC12_HIGH_STATE_NB_SYMBOL     ((uint8_t )3)       /* Nb high state symbol definition*/
#define  SIRC12_LOW_STATE_NB_SYMBOL      ((uint8_t )2)       /* Nb low state symbol definition*/
#define  SIRC12_ADDRESS_BITS             ((uint8_t )5)       /* Nb of data bits definition*/
#define  SIRC12_INSTRUCTION_BITS         ((uint8_t )7)       /* Nb of data bits definition*/
#define  SIRC12_HIGH_STATE_CODE          ((uint8_t )0x03)    /* SIRC12 high level definition*/
#define  SIRC12_LOW_STATE_CODE           ((uint8_t )0x01)    /* SIRC12 low level definition*/
#define  SIRC12_MAIN_FRAME_LENGTH        ((uint8_t )12)      /* Main frame length*/
#define  SIRC12_BIT_FORMAT_MASK          ((uint16_t)1)       /* Bit mask definition*/
#define  SIRC12_COUNTER_LIMIT            ((uint16_t)75)      /* main frame + idle time */
#define  SIRC12_IS_RUNNING               ((uint8_t)4)        /* SIRC12 Protocol number */
#define  SIRC12_HEADERS                  ((uint16_t)0x0F)    /* SIRC12 Start pulse */
#define  SIRC12_HEADERS_LENGTH           ((uint8_t)5)        /* Length of the headers */
#define  SIRC12_CODED_FRAME_TABLE_LENGTH ((uint8_t)2)        /* Coded frame table number of uint32_t word  */

#define MESSAGE1  "LEFT | RIGHT| DOWN  | SEL  "
#define MESSAGE2  "PREV | NEXT |SWITCH | SEND "



enum STATE
{
 RESET,
 SET
};

//decode code


#define SIRC_MESSAGE                    " SIRC InfraRed Demo  "

#define SIRC_TIME_OUT_US                4050

#define SIRC_STATUS_HEADER              1 << 1
#define SIRC_STATUS_RX                  1 << 0
#define INITIAL_STATUS                SIRC_STATUS_HEADER

#define SIRC_BIT_ERROR                  0xFF
#define SIRC_HEADER_ERROR               0xFF
#define SIRC_HEADER_OK                  0x00

#define SIRC_BITS_COUNT                 11
#define SIRC_TOTAL_BITS_COUNT           11

#define SIRC_ONTIME_MIN_US              (540)
#define SIRC_ONTIME_MAX_US              (1260)

#define SIRC_HEADER_LOW_MIN_US          (2250)
#define SIRC_HEADER_LOW_MAX_US          (2550)
#define SIRC_HEADER_WHOLE_MIN_US        (2940)
#define SIRC_HEADER_WHOLE_MAX_US        (3060)

#define SIRC_VALUE_STEP_US              600
#define SIRC_VALUE_MARGIN_US            100
#define SIRC_VALUE_00_US                1200



typedef struct
{
  uint8_t count;  /*!< Bit count */
  uint8_t status; /*!< Status */
  uint32_t data;  /*!< Data */
} tSIRC_packet;

typedef struct
{
  __IO uint8_t Command;   /*!< Command field */
  __IO uint8_t Address ;  /*!< Address field */
} SIRC_Frame_TypeDef;



void SIRC12_Shift_Table(uint32_t Table[]);
uint32_t SIRC12_MSBToLSB_Data(uint32_t Data ,uint8_t DataNbBits);
uint16_t SIRC12_BinFrameGeneration(uint8_t SIRC12_Address, uint8_t SIRC12_Instruction);
void SIRC12_AddStateFragment(uint8_t State, uint8_t freespace);
void SIRC12_AddHeadersFragment(uint8_t headers, uint8_t freespace);
void SIRC12_AddHeaders(uint8_t  Headers);
void SIRC12_PulseWidthModulationConvert(uint32_t  bindata, uint8_t bindatalength);
void SIRC12_Encode_SendFrame(uint8_t SIRC12_Address, uint8_t SIRC12_Instruction);
void SIRC12_Encode_SignalGenerate(uint32_t formaat[]);



void calibration(uint32_t calib);
void SIRC_ResetPacket(void);
uint8_t SIRC_DecodeHeader(uint32_t lowPulseLength, uint32_t wholePulseLength);
void SIRC_DataSampling(uint32_t lowPulseLength, uint32_t wholePulseLength);
void SIRC_Decode(SIRC_Frame_TypeDef *ir_frame);




#endif /* SRC_IR_H_ */
